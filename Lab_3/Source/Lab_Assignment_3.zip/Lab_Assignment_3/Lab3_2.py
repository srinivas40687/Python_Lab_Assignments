from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn import datasets
from sklearn.svm import SVC



DataSet=datasets.load_iris()
Data=DataSet.data
Target_Data=DataSet.target

xtrain,xtest,ytrain,ytest=train_test_split(Data,Target_Data,test_size=0.2,random_state=62)
xtrain_1,xtest_1,ytrain_1,ytest_1=train_test_split(Data,Target_Data,test_size=0.2,random_state=30)

svc_linear=SVC(kernel='linear')
svc_rbf=SVC(kernel='rbf')

svc_linear.fit(xtrain,ytrain)
yprediction=svc_linear.predict(xtest)
print("Linear kernel score is ",accuracy_score(yprediction,ytest))
print(yprediction)

svc_rbf.fit(xtrain_1,ytrain_1)
yprediction_1=svc_linear.predict(xtest_1)
print("RBF kernel score is ",accuracy_score(yprediction_1,ytest_1))
print(yprediction_1)