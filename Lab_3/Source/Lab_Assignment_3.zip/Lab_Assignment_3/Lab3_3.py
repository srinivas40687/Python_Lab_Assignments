from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize,sent_tokenize
from nltk.collocations import ngrams

from collections import Counter
import nltk


file = open("Input", "r")
Data = file.read()
print("Data in the text file:","\n",Data)

print("-----------------------")

lmtz = WordNetLemmatizer()
words = word_tokenize(Data)
print("Lemmatization of the words in the text file:")
for word in words:
  print(lmtz.lemmatize(word, pos='v'))

print("-----------------------")

print("Applying bigram on the data in text file:")
words_1 = word_tokenize(Data)
list = []
bigram = ngrams(words_1,2)
for a in bigram:
    list.append(a)
print(list)

print("-----------------------")

words_count = Counter(list)
print(" Calculating the bigram frequency of the words:")
print(words_count)

print("-----------------------")

print("Choosing the top 5 bigrams that has been repeated the most:")
frequency_count = nltk.FreqDist(list)
top_bigrams = frequency_count.most_common(5)
print(top_bigrams)

with open('Input' , 'r') as file:
    line = file.readlines()
fit= ''

for word in line:
    fit= fit + word
sentence_1 = sent_tokenize(fit)
rep_sentence_1 = []


for sent in sentence_1:
    for word,words in list:
        for ((c,m), l) in top_bigrams:
            if (word,words == c,m):
                rep_sentence_1.append(sent)

print("-----------------------")

print ("\n Going through the original text in the file and finding the sentences with those most repeated bi-grams")
freq_count = nltk.FreqDist(rep_sentence_1)
Finish = freq_count.most_common(5)
for key,value in Finish:
    print("\n",key)