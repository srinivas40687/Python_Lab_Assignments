from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn import neighbors,datasets


DataSet =datasets.load_iris()
Data=DataSet.data
Target_Data=DataSet.target

xtrain,xtest,ytrain,ytest=train_test_split(Data,Target_Data,test_size=0.2,random_state=42)

knn=neighbors.KNeighborsClassifier(n_neighbors=1)
knn.fit(xtrain,ytrain)
yprediction=knn.predict(xtest)

print("The accuracy score is ",accuracy_score(yprediction,ytest))
