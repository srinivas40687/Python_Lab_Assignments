from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris

DataSet = load_iris()
Classify = DataSet.data
Organize = DataSet.target
slen, swidth, plen, pwidth=train_test_split(Classify, Organize, test_size=0.2, random_state=30)

#LINEAR DISCRIMINANT ANALYSIS

LDA=LinearDiscriminantAnalysis()
LDA.fit(xtrain,ytrain)
ypredict=LDA.predict(xtest)

#LOGISTIC REGRESSION

logistic_Regression=LogisticRegression()
logistic_Regression.fit(slen, plen)
ypredict=logistic_Regression.predict(swidth)


print("The accuracy score is ", accuracy_score(ypredict, pwidth))